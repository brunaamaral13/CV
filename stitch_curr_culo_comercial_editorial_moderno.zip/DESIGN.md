---
name: Editorial Executive
colors:
  surface: '#fff8f5'
  surface-dim: '#e0d8d5'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf2ee'
  surface-container: '#f4ece8'
  surface-container-high: '#eee7e3'
  surface-container-highest: '#e9e1dd'
  on-surface: '#1e1b19'
  on-surface-variant: '#45474c'
  inverse-surface: '#33302d'
  inverse-on-surface: '#f7efeb'
  outline: '#75777c'
  outline-variant: '#c5c6cc'
  surface-tint: '#565f6f'
  primary: '#050e1c'
  on-primary: '#ffffff'
  primary-container: '#1b2432'
  on-primary-container: '#828b9d'
  inverse-primary: '#bec7da'
  secondary: '#9a4152'
  on-secondary: '#ffffff'
  secondary-container: '#fe90a1'
  on-secondary-container: '#782638'
  tertiary: '#170b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#331f00'
  on-tertiary-container: '#ac8348'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae3f6'
  primary-fixed-dim: '#bec7da'
  on-primary-fixed: '#131c2a'
  on-primary-fixed-variant: '#3e4757'
  secondary-fixed: '#ffd9dd'
  secondary-fixed-dim: '#ffb2bc'
  on-secondary-fixed: '#400012'
  on-secondary-fixed-variant: '#7c2a3b'
  tertiary-fixed: '#ffddb2'
  tertiary-fixed-dim: '#eebf7e'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#60400a'
  background: '#fff8f5'
  on-background: '#1e1b19'
  surface-variant: '#e9e1dd'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Newsreader
    fontSize: 34px
    fontWeight: '400'
    lineHeight: 42px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  metric-display:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.03em
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets commercial directors, rights agents, and sales leaders within high-stakes publishing houses, literary agencies, and global media groups. The aesthetic marries classic literary heritage with the velocity and rigor of modern executive fintech. It eschews generic corporate SaaS motifs in favor of tactile editorial luxury, invoking fine book jacket design, bespoke bindery textures, and high-density financial reporting.

### Emotional Signature & Demeanor
- **Literary Authority:** Evoking heavy-grammage paper stocks, bespoke typesetting, and century-old publishing houses.
- **Commercial Precision:** Providing relentless data clarity, crisp KPI hierarchies, pipeline velocity, and catalog contract statuses.
- **Tactile Refinement:** Utilizing warm eggshell backgrounds, subtle rule-lines, razor-thin framing, and warm-tinted depth.

### Design Movement
**Modern Editorial Minimalism & Tactile Structure.** Clean, asymmetrical layouts governed by architectural typographic scales, fine hairline divisions (0.5pt rules), and rich velvet-toned accents rather than loud, synthetic primary buttons.

## Colors

The palette draws directly from classic book craft: archival ink, morocco leather, hot-stamped gold foil, and warm deckle-edge paper.

### Primary Palette
- **Primary Ink (`#1B2432`):** Midnight Oxford Navy. Anchors primary actions, high-emphasis headers, active navigation tabs, and critical structural lines.
- **Secondary Accent (`#6C1D2F`):** Deep Port / Bordeaux. Used for key conversion moments, rights-deal highlights, critical stage gates, and prominent badges.
- **Tertiary Accent (`#B88E52`):** Burnished Gold / Gilt. Highlights VIP imprints, royalty thresholds, and premium contractual tiers.
- **Neutral Foreground (`#1A1715`):** Carbon Ink. Ensures maximum legible body contrast without the clinical starkness of pure black.

### Surface Tones & Canvases
- **Base Canvas (`#F9F7F2`):** Cream Vellum. A warm, non-glare editorial paper surface.
- **Surface Layer 1 (`#FFFFFF`):** Pressed Linen. Used for cards, sheets, tables, and modal dialogues.
- **Surface Layer 2 (`#F2EEE6`):** Antique Endpaper. Soft container background for secondary metrics, table headers, and inactive states.
- **Borders & Dividers (`#E2DDD2`):** Bookbinder's Thread. Hairline rules (1px) framing components cleanly without visual noise.

### Functional Status Tokens
- **Positive / Acquired (`#1F5C45`):** Forest Spruce.
- **Warning / Rights Expiring (`#A65B17`):** Amber Resin.
- **Critical / Returned (`#8A2424`):** Venetian Crimson.
- **Informative / Under Review (`#264E70`):** Slate Indigo.

## Typography

The typographic engine balances literary tradition with raw operational readability.

- **Headlines (`Newsreader`):** An authoritative editorial serif with optical sizing characteristics. Used for executive report titles, imprint names, author headliners, and macro portfolio valuations.
- **Body & Controls (`Hanken Grotesk`):** A modern, geometric grotesque with tight apertures and high legibility. Delivers effortless scanning of complex royalties, book distribution logs, and contract parameters.
- **Metadata & Technicals (`JetBrains Mono`):** Applied to ISBNs, SKU numbers, currency indicators, timestamps, audit trail data, and print-run run-rates. Set predominantly in uppercase with slight tracking for swift cross-referencing.

## Layout & Spacing

The layout is built mobile-first, designed for a sales VP reviewing title turnover and negotiating foreign rights on an iPhone during the Frankfurt Book Fair, then docking into an ultrawide desktop station for quarterly P&L analysis.

### Structural Grid Architecture
- **Mobile (`< 768px`):** 4-column fluid layout, single-column KPI stacks, sticky bottom action bar, horizontal scrolling mini-cards for sub-rights deals.
- **Tablet (`768px - 1024px`):** 8-column layout with split title-catalogs and inline metadata drawers.
- **Desktop (`> 1024px`):** 12-column fixed/fluid hybrid system (max content width `1440px`), allowing dual-pane master-detail inspect panels for contracts and run-rates.

### Spatial Rhythm
Spacing flows on a modular 4px/8px cadence. Editorial rhythm prioritizes generous white margins around key literary announcements, balanced with compressed tabular zones (`space-xs` and `space-sm`) for inventory runs, advance vs. royalty reconciliations, and territory sell-through tables.

## Elevation & Depth

The design system adopts **Tonal Layering with Archival Shadows and Crisp Rule Framing**. Glassmorphism and exaggerated floating shadows are avoided to prevent an artificial, software-gimmick feel.

### Depth Stratification
1. **Canvas Surface (`#F9F7F2`):** Base canvas containing broad visual fields and editorial narrative.
2. **Resting Cards (`#FFFFFF`):** Clean pressed-paper cards elevated by a single hair-thin border (`#E2DDD2`) and an ambient, warm-tinted shadow: `0 1px 3px rgba(26, 23, 21, 0.04), 0 4px 12px rgba(26, 23, 21, 0.02)`.
3. **Hover & Interactive State:** Soft lift accompanied by border darkening (`#B88E52` at 40% opacity) and an extended warm shadow: `0 8px 24px rgba(26, 23, 21, 0.08)`.
4. **Modal Drawers & Executive Overlays:** Grounded with a rich vellum wash backdrop filter (`rgba(27, 36, 50, 0.45)` with `backdrop-filter: blur(4px)`) and a structured card shadow: `0 16px 40px rgba(27, 36, 50, 0.16)`.

## Shapes

The design system employs **Soft (`1`)** roundedness. Curvatures are deliberately tailored to feel like precision-cut paper, book boards, and luxury stationery rather than soft, playful software bubbles.

- **Base Components (Inputs, Buttons, Badges):** `0.25rem` (4px). Clean, razor-trimmed corners.
- **Cards & Data Modules (`rounded-lg`):** `0.5rem` (8px). Maintains structure while softening viewport edges.
- **Executive Modals & Sheets (`rounded-xl`):** `0.75rem` (12px). Applied strictly to top corners of bottom sheets on mobile devices.
- **Decorative Tags:** High-density catalog status pills use full rounding (`9999px`) only when indicating binary catalog states (e.g., *Out of Print*, *In Rights Auction*).

## Components

### Buttons
- **Primary Action (Oxford Navy):** Background `#1B2432`, Text `#FFFFFF`, font `Hanken Grotesk` 14px Weight 600. Minimal interior padding: `10px 20px`. Border: 1px solid `#1B2432`. Hover: `#28364A`. Active: gentle `scale(0.99)`.
- **Secondary Action (Bordeaux Elegance):** Background `transparent`, Border `1px solid #6C1D2F`, Text `#6C1D2F`. Hover: Background `rgba(108, 29, 47, 0.05)`.
- **Tertiary / Utility:** Text `#1B2432`, font `Hanken Grotesk` 14px Weight 500, underline offset 4px on hover.

### Badges & Status Chips
- **Commercial Tags:** Minimalist, uppercase micro-typography (`JetBrains Mono` 10px Weight 500). Padding: `2px 8px`. Border-radius: `3px`.
- **Rights Status Palette:**
  - *Under Option:* Background `#FAF3E8`, Text `#8A601B`, Border: `1px solid #E8D2A8`.
  - *Firm Deal:* Background `#EDF5F1`, Text `#1B5E41`, Border: `1px solid #BCDBCB`.
  - *Lapsed / Reverted:* Background `#F9EDEC`, Text `#822320`, Border: `1px solid #E6B8B5`.

### Cards & Commercial Metric Tiles
- **Structure:** Surface `#FFFFFF`, Border `1px solid #E2DDD2`, internal padding `1.25rem`.
- **Header Slot:** Small uppercase mono kicker (`JetBrains Mono` 11px), followed by a serif metric context label (`Newsreader` 18px).
- **Metric Core:** Stat numbers in `Hanken Grotesk` 32px Bold (`#1B2432`), paired with delta trend chips (+14.2% YoY in spruce green).
- **Divider:** Subtle hairline `1px solid #EFECE6`.

### Inputs & Field Controls
- **Form Fields:** Vellum background `#FFFFFF`, Border: `1px solid #D6D0C4`, Height: 44px (touch target friendly), Text: `#1A1715`. Focused state: Border `1px solid #1B2432`, with an instant 0-spread halo of `rgba(27, 36, 50, 0.12)`.
- **Checkboxes & Radios:** Hand-pressed appearance, 16px square with 3px border radius. Checked state fills with `#1B2432` with an off-white inner checkmark icon.

### Tables & Data Grids (Editorial Catalog)
- **Header:** Sticky, Background `#F2EEE6`, Text `#1A1715` in `JetBrains Mono` 11px uppercase tracking `0.06em`. Border-bottom: `2px solid #1B2432`.
- **Rows:** Alternating subtle ivory hover (`#FAF8F5`). Border-bottom: `1px solid #EAE6DD`. Cell padding: `12px 16px`.
- **Numerical Alignment:** Monospaced figures aligned right for direct visual comparison of revenue advances and units sold.

### Book Cover & Deal Previews
- **Aspect Ratio:** Fixed 1:1.5 portrait container.
- **Card Framing:** Delicate inset stroke `1px inset rgba(0, 0, 0, 0.08)` to simulate the 3D cut edge of a dust jacket.